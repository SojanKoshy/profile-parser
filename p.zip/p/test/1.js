var fs      = require('fs');
var profile = require('/home/sojan/Desktop/linkedIn/node_modules/linkedin-public-profile-parser/lib/profile');
var file =  '/home/sojan/Desktop/linkedIn/node_modules/linkedin-public-profile-parser/test/fixtures/iteles.html'
var url = 'https://www.linkedin.com/in/iteles';

fs.readFile(file, function(err, html) {
  profile(url, html, function(err, data){
    console.log(JSON.stringify(data, null, 2));
  })
})